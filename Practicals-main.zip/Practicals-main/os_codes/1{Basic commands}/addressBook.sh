#!/bin/bash

# Address Book File
ADDRESS_BOOK="address_book.txt"

# Create Address Book
create_address_book() {
    touch "$ADDRESS_BOOK"
    echo "Address book created!"
}

# View Address Book
view_address_book() {
    if [ -s "$ADDRESS_BOOK" ]; then
        echo -e "\nAddress Book:"
        cat "$ADDRESS_BOOK"
    else
        echo "Address book is empty."
    fi
}

# Insert a Record
insert_record() {
    echo "Enter name:"
    read name
    echo "Enter phone number:"
    read phone
    echo "Enter email:"
    read email
    echo "$name: $phone, $email" >> "$ADDRESS_BOOK"
    echo "Record for $name added."
}

# Delete a Record
delete_record() {
    echo "Enter name to delete:"
    read name
    sed -i "/^$name:/d" "$ADDRESS_BOOK"
    if [ $? -eq 0 ]; then
        echo "Record for $name deleted."
    else
        echo "No record found for $name."
    fi
}

# Modify a Record
modify_record() {
    echo "Enter name to modify:"
    read name
    if grep -i "^$name:" "$ADDRESS_BOOK"; then
        echo "Enter new phone number:"
        read phone
        echo "Enter new email:"
        read email
        sed -i "/^$name:/d" "$ADDRESS_BOOK"
        echo "$name: $phone, $email" >> "$ADDRESS_BOOK"
        echo "Record for $name modified."
    else
        echo "No record found for $name."
    fi
}

# Main Menu
while true; do
    echo -e "\nOptions:"
    echo "a) Create address book"
    echo "b) View address book"
    echo "c) Insert a record"
    echo "d) Delete a record"
    echo "e) Modify a record"
    echo "f) Exit"
    
    read -p "Select an option (a/b/c/d/e/f): " option

    case $option in
        a) create_address_book ;;
        b) view_address_book ;;
        c) insert_record ;;
        d) delete_record ;;
        e) modify_record ;;
        f) echo "Exiting the program."; exit 0 ;;
        *) echo "Invalid option. Please try again." ;;
    esac
done
